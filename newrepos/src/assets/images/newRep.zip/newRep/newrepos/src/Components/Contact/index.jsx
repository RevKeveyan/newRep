import React, {Component} from "react";

export class Contact extends Component{


    render() {
        return <div>
            <h2>Contact</h2>
        </div>
    }
}