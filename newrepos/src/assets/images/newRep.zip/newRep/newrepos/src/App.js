// import Header1 from './homeWork/header';

import { Routing } from "./Components/Routes";
import {Routes,Route} from "react-router-dom";
import {Home} from "./Components/Home/idnex";
import {About} from "./Components/About";
import {Contact} from "./Components/Contact";

// import { List } from "./Components/Lists";


function App() {
  return (
    <div className="App">
      {/* <Header1/> */}
      {/* <List /> */}
      <Routing />
      <Routes>
          <Route path="/home" element={<Home />}/>
          <Route path="/about" element={<About />}/>
          <Route path="/contact" element={<Contact />}/>
          <Route path="/*" element={<Home />}/>
      </Routes>
    </div>
  );
}

export default App;
